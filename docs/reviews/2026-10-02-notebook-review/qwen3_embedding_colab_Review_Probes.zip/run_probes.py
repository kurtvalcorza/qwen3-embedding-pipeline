"""Row 72 probes: qwen3-embedding-pipeline tutorials/qwen3_embedding_colab.ipynb @ f9f5c81 (blob f3475b93).

Phases (argv[1]):
  static   - source inspection probes, Banking77 leakage scan, BYOD size arithmetic (no model)
  default  - CPU direct execution of the notebook's code cells in order (install skipped, pins
             approximated by the local env), then the documented optional experiment
             TRAINABLE_LAYERS = 1 re-run of Sections 7-9 and a re-run of Section 6
  byod     - fresh process: carried cells + model, then Section 4 with USE_BYOD=True through a
             google.colab upload shim on BYOD-shaped stand-ins, then Sections 5-9 on one that loads

Environment: Windows, eo-notebook-test conda env (torch 2.13.0+cpu, transformers 4.57.6, numpy 2.5.3),
CUDA_VISIBLE_DEVICES=-1, CPU float32. NOT a Colab run and NOT promotion evidence.
Results are merged into results.json next to this file (write-immediately).
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import sys
import time
import traceback
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
NB = Path(os.environ['R72_NOTEBOOK'])
RUN_DIR = HERE / 'run'
RESULTS = HERE / 'results.json'


def save(key, value):
    data = json.loads(RESULTS.read_text(encoding='utf-8')) if RESULTS.exists() else {}
    data[key] = value
    RESULTS.write_text(json.dumps(data, indent=1, default=str), encoding='utf-8')


nb = json.loads(NB.read_text(encoding='utf-8'))
cells = nb['cells']
src = [''.join(c['source']) for c in cells]
code_idx = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
module_idx = [i for i in code_idx if cells[i].get('metadata', {}).get('dimer', {}).get('embedded_module')]


def run_cell(ns, i, source=None, label=None):
    buf = io.StringIO()
    t0 = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf):
        try:
            exec(compile(source if source is not None else src[i], f'<cell {i}>', 'exec'), ns)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {str(exc)[:400]}'
    out = buf.getvalue()
    sys.stdout.write(f'--- cell {i} {label or ""} ({time.perf_counter() - t0:.1f}s) err={err}\n{out[-3000:]}\n')
    sys.stdout.flush()
    return {'cell': i, 'label': label, 'seconds': round(time.perf_counter() - t0, 1), 'error': err, 'stdout_tail': out[-1500:]}


def static():
    res = {}
    md = '\n'.join(s for s, c in zip(src, cells) if c['cell_type'] == 'markdown')
    # S1 install cell: in-kernel pip install with a raise-and-restart guard
    res['install_cell_pip_into_kernel'] = "'-m', 'pip', 'install'" in src[3]
    res['install_cell_restart_raise'] = 'Restart the runtime, then rerun from the top' in src[3]
    res['uses_uv'] = 'uv venv' in ''.join(src) or "'uv'" in ''.join(src)
    # S2 guided layer markers (NOTEBOOK_SPEC 2.2 GDL) - case-insensitive phrase search over markdown
    markers = {
        'how_to_use': r'how to use this notebook',
        'roadmap': r'roadmap|what you will do',
        'glossary': r'glossary|key terms',
        'prediction_prompt': r'predict(ion)?\b.*before|before you run.*predict|\bpredict:',
        'checkpoint': r'checkpoint|check your understanding',
        'infrastructure_label': r'infrastructure',
        'troubleshooting': r'troubleshoot',
        'conclusion_template': r'conclusion template|write your conclusion|your conclusion',
        'worked_answer': r'worked answer|sample answer|answer:',
        'exercise_section': r'^#+ .*(exercise|try it|your turn)',
    }
    res['guided_markers'] = {k: bool(re.search(p, md, re.I | re.M)) for k, p in markers.items()}
    res['markdown_headings'] = [l for l in md.splitlines() if l.startswith('#')]
    # S3 BYOD uses google.colab only, no path parameter
    res['byod_imports_google_colab'] = 'from google.colab import files' in src[13]
    res['byod_path_param'] = bool(re.search(r'BYOD_PATH|DATA_PATH|byod_file', src[13]))
    # S4 input manifest covers document_set[:MAX_BATCH] while prose says the 77 documents
    res['input_manifest_slice'] = 'validate_inputs(document_set[:MAX_BATCH]' in src[15]
    res['prose_claims_77_manifest'] = 'input manifest for the 77 documents' in src[14]
    # S5 adapt never resets to the pretrained base; epoch 0 always labelled 'frozen model'
    pipe_src = src[7]
    res['adapt_resets_base'] = bool(re.search(r'def adapt[\s\S]*?(reset|_pristine|base_state|reload)', pipe_src.split('def save_artifact')[0]))
    res['epoch0_note_frozen_literal'] = '"note": "frozen model"' in pipe_src
    res['optional_experiments_text'] = re.search(r'\*\*Optional experiments[^\n]*', src[24]).group(0)
    res['rerun_instruction_present'] = bool(re.search(r're-?run (cells|from|sections?)', src[24], re.I))
    # S6 quoted numbers in prose vs the recorded hosted run (Kaggle T4 2026-09-19, adapted recall@1 0.7662)
    res['prose_quotes_80_3'] = [i for i, s in enumerate(src) if '80.3' in s]
    res['prose_val_recall5_95'] = 'recall@5 passes 95' in src[18]
    # S7 unconditional asserts on the BYOD path
    res['asserts'] = {i: re.findall(r'^assert .*$', src[i], re.M) for i in code_idx if re.search(r'^assert ', src[i], re.M)}
    res['section5_hard_three_queries'] = 'query_vectors.shape == (3, EMBEDDING_DIM)' in src[15]
    save('static', res)

    # Leakage scan and BYOD arithmetic need the carried modules (numpy only, no torch import at module level)
    ns = {'__name__': '__main__'}
    for i in module_idx:
        exec(compile(src[i], f'<cell {i}>', 'exec'), ns)
    files = {}
    for key, (name, size, digest) in ns['CORPUS_FILES'].items():
        data = (RUN_DIR / 'weights' / 'banking77' / name).read_bytes()
        assert len(data) == size and hashlib.sha256(data).hexdigest() == digest, name
        files[key] = data
    corpus = ns['read_corpus'](ns['fetch_corpus'](cache_dir=str(RUN_DIR / 'weights' / 'banking77')))
    splits = ns['build_sample_dataset'](corpus, seed=42)
    leak = {'sizes': {k: len(v) for k, v in splits.items()}}

    def norm(t):
        return ' '.join(re.findall(r'[a-z0-9]+', t.lower()))

    def toks(t):
        return set(re.findall(r'[a-z0-9]+', t.lower()))

    test = splits['test']
    trainval = splits['train'] + splits['validation']
    tv_norm = {}
    for r in trainval:
        tv_norm.setdefault(norm(r['query']), []).append(r)
    exact_norm = [(r['query'], tv_norm[norm(r['query'])][0]['query']) for r in test if norm(r['query']) in tv_norm]
    near = []
    tv_toks = [(toks(r['query']), r) for r in trainval]
    for r in test:
        a = toks(r['query'])
        best = max((((len(a & b) / len(a | b)) if a | b else 0.0, q) for b, q in tv_toks), key=lambda t: t[0])
        if best[0] >= 0.8:
            near.append({'test': r['query'], 'train': best[1]['query'], 'jaccard': round(best[0], 3),
                         'same_intent': r['positive'] == best[1]['positive']})
    leak['test_vs_trainval_normalized_exact'] = len(exact_norm)
    leak['examples_normalized_exact'] = exact_norm[:5]
    leak['test_vs_trainval_jaccard_ge_0.8'] = len(near)
    leak['near_examples'] = near[:8]
    # Whole-release scale for context
    all_train = {norm(r['text']) for r in corpus['train']}
    leak['release_test_rows_normalized_in_release_train'] = sum(norm(r['text']) in all_train for r in corpus['test'])
    save('leakage', leak)

    # BYOD size arithmetic: does Section 4 (split + validate_dataset per split with default min 8) and
    # Section 5 (hard 3 test queries) accept n records over 8 positives?
    arith = {}
    for n in (8, 12, 13, 20, 37, 38, 53, 54, 60):
        recs = [{'id': f'r{i}', 'query': f'user message number {i} about topic {i % 8}', 'positive': f'topic {i % 8}'} for i in range(n)]
        row = {}
        try:
            sp = ns['split_dataset'](recs, seed=42)
            row['split'] = {k: len(v) for k, v in sp.items()}
            for name, part in sp.items():
                ns['validate_dataset'](part)
            row['section4'] = 'ok'
            row['section5_three_queries'] = len(sp['test']) >= 3
        except Exception as exc:  # noqa: BLE001
            row['section4'] = f'{type(exc).__name__}: {exc}'
        arith[n] = row
    save('byod_arithmetic', arith)
    print(json.dumps({'static': res, 'leakage': leak, 'byod_arithmetic': arith}, indent=1, default=str)[:6000])


def model_ns():
    os.chdir(RUN_DIR)
    os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
    ns = {'__name__': '__main__'}
    return ns


def default():
    ns = model_ns()
    log = []
    for i in code_idx:
        r = run_cell(ns, i, label='default')
        log.append(r)
        save('default_cells', log)
        if r['error']:
            break
    summary = {}
    if 'comparison' in ns:
        summary['comparison'] = ns['comparison']
        summary['history'] = [{'epoch': h['epoch'], 'val_mrr': h['val'] and round(h['val']['mrr'], 4), 'val_r1': h['val'] and round(h['val']['recall@1'], 4), 'val_r5': h['val'] and round(h['val']['recall@5'], 4), 'note': h.get('note')} for h in ns['adapt_result']['history']]
        summary['parity'] = ns.get('parity')
        summary['document_shift'] = ns.get('document_shift')
        summary['rows'] = ns.get('rows')
        summary['outputs'] = sorted(os.listdir('outputs'))
        summary['runtime'] = {'torch': ns['torch'].__version__, 'transformers': ns['transformers'].__version__, 'device': ns['pipe'].device}
    save('default_summary', summary)
    if any(r['error'] for r in log):
        return
    # Active learning: documented optional experiment "set TRAINABLE_LAYERS = 1 and watch the gain shrink".
    al = {'before_rerun_adapter_present': ns['pipe'].adapter is not None}
    s19 = src[19].replace('TRAINABLE_LAYERS = 2  # @param', 'TRAINABLE_LAYERS = 1  # @param')
    assert s19 != src[19]
    steps = [run_cell(ns, 19, s19, 'AL TRAINABLE_LAYERS=1')]
    al['epoch0_after_rerun'] = ns['adapt_result']['history'][0]
    al['epoch0_default_run'] = summary['history'][0]
    al['history'] = [{'epoch': h['epoch'], 'val_mrr': h['val'] and round(h['val']['mrr'], 4), 'note': h.get('note')} for h in ns['adapt_result']['history']]
    save('active_learning', al)
    steps.append(run_cell(ns, 21, label='AL Section 8'))
    al['comparison_after_rerun'] = ns.get('comparison')
    save('active_learning', al)
    steps.append(run_cell(ns, 23, label='AL Section 9'))
    al['parity_after_rerun'] = ns.get('parity')
    al['steps'] = steps
    save('active_learning', al)
    # Rerun Section 6 ("change INSTRUCTION and re-read the frozen numbers"): what does 'frozen' score now?
    s6 = run_cell(ns, 17, label='Section 6 rerun after adaptation')
    al['section6_rerun'] = {'step': s6, 'frozen_test_adapted_flag': ns['frozen_test'].get('adapted'), 'frozen_test_mrr': round(ns['frozen_test']['mrr'], 4), 'default_frozen_mrr': summary['comparison']['mrr']['frozen']}
    save('active_learning', al)


def byod():
    ns = model_ns()
    log = []
    for i in code_idx[:module_idx[-1] + 1 and 5]:
        pass
    # cells up to and including Section 3 (install skipped, carried modules, model load)
    for i in [c for c in code_idx if c <= 11]:
        r = run_cell(ns, i, label='setup')
        log.append(r)
        if r['error']:
            save('byod', {'setup': log})
            return
    # google.colab upload shim
    holder = {}
    colab = types.ModuleType('google.colab')
    colab.files = types.SimpleNamespace(upload=lambda: dict(holder))
    google = types.ModuleType('google')
    google.colab = colab
    sys.modules['google'] = google
    sys.modules['google.colab'] = colab
    corpus = ns['read_corpus'](ns['fetch_corpus'](cache_dir='weights/banking77'))
    pool = ns['filter_records'](corpus['test'])
    intents = sorted({r['intent'] for r in pool})[:8]

    def pick(n, n_intents=8):
        out = []
        per = {}
        for r in pool:
            if r['intent'] in intents[:n_intents] and per.get(r['intent'], 0) < (n + n_intents - 1) // n_intents and len(out) < n:
                per[r['intent']] = per.get(r['intent'], 0) + 1
                out.append({'id': f'q{len(out)}', 'query': r['query'], 'positive': r['positive']})
        return out

    def to_csv(recs):
        buf = io.StringIO()
        import csv
        w = csv.DictWriter(buf, fieldnames=['id', 'query', 'positive'])
        w.writeheader()
        w.writerows(recs)
        return buf.getvalue().encode()

    stand_ins = {
        'stated_minimum_8.csv': to_csv(pick(8)),
        'n12.csv': to_csv(pick(12)),
        'n40.csv': to_csv(pick(40)),
        'n80.csv': to_csv(pick(80)),
        'missing_column.csv': b'id,text,positive\na,hello,b\n',
        'notes.txt': b'id,query,positive\n',
    }
    s13 = src[13].replace('USE_BYOD = False  # @param', 'USE_BYOD = True  # @param')
    results = {}
    for name, payload in stand_ins.items():
        holder.clear()
        holder[name] = payload
        r = run_cell(ns, 13, s13, f'BYOD {name}')
        row = {'section4': r['error'] or 'ok'}
        if not r['error']:
            r5 = run_cell(ns, 15, label=f'BYOD {name} Section 5')
            row['section5'] = r5['error'] or 'ok'
            row['splits'] = ns.get('disjoint')
        results[name] = row
        save('byod', {'setup': log, 'stand_ins': results})
    # Full downstream on the largest stand-in that passed Sections 4-5 (fresh base: never adapted in this process)
    ok = [n for n, row in results.items() if row.get('section5') == 'ok']
    if ok:
        name = ok[-1]
        holder.clear()
        holder[name] = stand_ins[name]
        down = [run_cell(ns, 13, s13, f'BYOD {name} full')]
        for i in (15, 17, 19, 21, 23):
            r = run_cell(ns, i, label=f'BYOD {name} full')
            down.append(r)
            if r['error']:
                break
        results['downstream'] = {'dataset': name, 'steps': [{'cell': d['cell'], 'error': d['error'], 'seconds': d['seconds']} for d in down], 'comparison': ns.get('comparison') if not down[-1]['error'] or down[-1]['cell'] > 21 else None}
    save('byod', {'setup': log, 'stand_ins': results})


def al():
    """Active learning in a fresh process (the in-process continuation hit the 590 s probe cap).
    Sections 1-6 run on the pristine base (true frozen numbers), then the default run's own exported
    adapter is overlaid with load_artifact, reproducing the exact post-default in-memory state (reload
    parity was exact in the default run). Then: Section 6 re-run ('change INSTRUCTION and re-read the
    frozen numbers' with INSTRUCTION unchanged), and the documented TRAINABLE_LAYERS = 1 re-run of 7-9."""
    ns = model_ns()
    log = []
    for i in [c for c in code_idx if c <= 17]:
        r = run_cell(ns, i, label='AL setup')
        log.append(r)
        if r['error']:
            save('active_learning', {'setup': log})
            return
    true_frozen = ns['frozen_test']
    ns['pipe'].load_artifact('default_adapter')
    al = {'state': 'pristine base Sections 1-6, then default-run adapter overlaid (load_artifact)', 'true_frozen_test_mrr': round(true_frozen['mrr'], 4), 'true_frozen_test_r1': round(true_frozen['recall@1'], 4)}
    s6 = run_cell(ns, 17, label='Section 6 rerun after adaptation')
    al['section6_rerun'] = {'error': s6['error'], 'stdout': s6['stdout_tail'], 'frozen_test_adapted_flag': ns['frozen_test'].get('adapted'), 'frozen_test_mrr': round(ns['frozen_test']['mrr'], 4), 'frozen_test_r1': round(ns['frozen_test']['recall@1'], 4)}
    save('active_learning', al)
    ns['frozen_test'] = true_frozen
    s19 = src[19].replace('TRAINABLE_LAYERS = 2  # @param', 'TRAINABLE_LAYERS = 1  # @param')
    assert s19 != src[19]
    st = run_cell(ns, 19, s19, 'AL TRAINABLE_LAYERS=1')
    al['cell19'] = {'error': st['error'], 'stdout': st['stdout_tail'], 'seconds': st['seconds']}
    al['history'] = [{'epoch': h['epoch'], 'val_mrr': h['val'] and round(h['val']['mrr'], 4), 'val_r1': h['val'] and round(h['val']['recall@1'], 4), 'note': h.get('note')} for h in ns['adapt_result']['history']]
    save('active_learning', al)
    st = run_cell(ns, 21, label='AL Section 8')
    al['cell21'] = {'error': st['error'], 'seconds': st['seconds']}
    al['comparison_after_rerun'] = ns.get('comparison')
    save('active_learning', al)
    st = run_cell(ns, 23, label='AL Section 9')
    al['cell23'] = {'error': st['error'], 'stdout': st['stdout_tail'], 'seconds': st['seconds']}
    al['parity_after_rerun'] = ns.get('parity')
    save('active_learning', al)


def byod_min():
    """Smallest BYOD record count that passes Section 4 (split_dataset + validate_dataset on every split)."""
    ns = {'__name__': '__main__'}
    for i in module_idx:
        exec(compile(src[i], f'<cell {i}>', 'exec'), ns)
    passing = []
    for n in range(8, 121):
        recs = [{'id': f'r{i}', 'query': f'user message number {i} about topic {i % 8}', 'positive': f'topic {i % 8}'} for i in range(n)]
        try:
            sp = ns['split_dataset'](recs, seed=42)
            for part in sp.values():
                ns['validate_dataset'](part)
            passing.append(n)
        except ValueError:
            pass
    res = {'smallest_passing': min(passing), 'failing_at_or_above_smallest': [n for n in range(min(passing), 121) if n not in passing], 'stated_minimum': 8}
    save('byod_minimum', res)
    print(res)


if __name__ == '__main__':
    {'static': static, 'default': default, 'byod': byod, 'al': al, 'byod_min': byod_min}[sys.argv[1]]()
